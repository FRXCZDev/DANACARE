<?php 
$id_telegram = "6179252533";
$id_botTele = "7186513446:AAHidYIWU2GM2PoT5oRdwyOCIu_uBRphH_E";
?>